package manhuntgame.app;

public interface IKeyboardHeightListener
{
    void init();

    double getUsableWindowHeight();
}
