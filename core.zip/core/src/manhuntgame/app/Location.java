package manhuntgame.app;

public class Location
{
    public static double latitude = 0;
    public static double longitude = 0;
    public static double altitude = 0;
    public static double compass = 0;
}
