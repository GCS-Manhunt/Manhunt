package manhuntgame.ui.screen;

public abstract class Screen
{
    public abstract void update();

    public abstract void draw();
}
