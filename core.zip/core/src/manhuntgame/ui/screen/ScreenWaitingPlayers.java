package manhuntgame.ui.screen;

// a sort of waiting screen for non-host players after they select their username.
// it should tell us how many players are currently in, tell you to wait until the host starts,
// and give you the option to exit if needed.
// comes after ScreenSelectUsername

import manhuntgame.ui.TextBox;
import manhuntgame.app.App;
import manhuntgame.app.Drawer;

public class ScreenWaitingPlayers extends Screen {
    @Override
    public void update()
    {
        //
    }

    @Override
    public void draw()
    {

    }
}