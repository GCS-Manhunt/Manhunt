package manhuntgame.ui.screen;

import manhuntgame.ui.TextBox;
import manhuntgame.app.App;
import manhuntgame.app.Drawer;

public class ScreenSelectUsername extends Screen
{
    @Override
    public void update()
    {

    }

    @Override
    public void draw()
    {

    }
}
