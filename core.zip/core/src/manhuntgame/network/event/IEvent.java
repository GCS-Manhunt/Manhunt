package manhuntgame.network.event;

public interface IEvent 
{

}
