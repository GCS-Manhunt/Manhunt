package manhuntgame.network.event;

import io.netty.buffer.ByteBuf;

public class EventPing implements INetworkEvent
{
	public EventPing()
	{
		
	}

	@Override
	public void write(ByteBuf b)
	{
		
	}

	@Override
	public void read(ByteBuf b)
	{
		
	}

	@Override
	public void execute() 
	{
		
	}

}
