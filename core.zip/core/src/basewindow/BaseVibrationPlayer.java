package basewindow;

public abstract class BaseVibrationPlayer
{
    public abstract void selectionChanged();

    public abstract void click();

    public abstract void heavyClick();
}
