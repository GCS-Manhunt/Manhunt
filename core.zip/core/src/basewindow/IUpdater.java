package basewindow;

public interface IUpdater 
{	
	void update();
}
