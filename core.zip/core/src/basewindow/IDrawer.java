package basewindow;

public interface IDrawer 
{
	void draw();
}
