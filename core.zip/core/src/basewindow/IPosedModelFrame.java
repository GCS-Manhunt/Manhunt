package basewindow;

public interface IPosedModelFrame
{
}
