package basewindow;

public interface IWindowHandler 
{
	void onWindowClose();
}
